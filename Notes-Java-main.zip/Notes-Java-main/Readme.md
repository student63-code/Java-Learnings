Java Concepts

Learnt About Output 

Println features 
