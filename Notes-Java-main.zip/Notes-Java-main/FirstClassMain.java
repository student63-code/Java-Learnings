// output println 
    public class FirstClassMain {
    public static void main(String[] args) {
        System.out.println("My World");
        System.out.println("Sakshi Joshi");
        System.out.println( "Discover New Ideas");
        System.out.println("I am learning Java.");
    System.out.println("It is awesome!");
    }
}

